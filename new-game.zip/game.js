import './birdjs.js';
import './assets.js';
/* Angry Birds demo built on BirdJS */
(function () {
  'use strict';
  const { Body, World, Assets, Audio, Camera, Input, Loop, Particles, Storage, Util: U } = BirdJS;
  const $ = (id) => document.getElementById(id);
  const cv = $('c'), ctx = cv.getContext('2d');

  /* ---------------- constantes ---------------- */
  const S = 0.7;            // block and pig scale
  const BS = 0.8;           // bird scale
  const VIEW_H = 720;       // visible world height
  const GY = 620;           // ground y
  const WORLD_W = 2500;
  const OX = -330;          // horizontal offset de las estructuras
  const SX = 250, SY = GY - 112; // slingshot anchor
  const MAXD = 100, KPOW = 9.5, GRAV = 850;
  const FONT = "'Arial Black', Impact, 'Segoe UI', sans-serif";
  const TAU = Math.PI * 2;

  const MAT = {
    wood: { d: 0.8, f: 0.6, e: 0.1, K: 380, pts: 500, col: ['#b8742c', '#8a5220', '#d9953f'], col_: 'wood_collision_a', dm: 'wood_damage_a', ds: 'wood_destroyed_a' },
    ice: { d: 0.5, f: 0.3, e: 0.08, K: 260, pts: 400, col: ['#9fd4ee', '#cfeefa', '#6bb4da'], col_: 'ice_light_collision_a', dm: 'light_damage_a', ds: 'light_destroyed_a' },
    stone: { d: 1.8, f: 0.7, e: 0.05, K: 900, pts: 800, col: ['#9a9a9a', '#6f6f6f', '#c0c0c0'], col_: 'rock_collision_a', dm: 'rock_damage_a', ds: 'rock_destroyed_a' },
    tnt: { d: 0.7, f: 0.5, e: 0.1, K: 60, pts: 1000, col: ['#c33', '#fff', '#a22'], col_: 'wood_collision_a', dm: 'wood_damage_a', ds: 'wood_destroyed_a' },
  };
  const BIRDS = {
    red: { r: 15, d: 2.0, snd: '01', name: 'Red' },
    blue: { r: 11, d: 2.0, snd: '02', name: 'Blues' },
    chuck: { r: 15, d: 2.0, snd: '03', name: 'Chuck' },
    bomb: { r: 21, d: 2.4, snd: '04', name: 'Bomb' },
    matilda: { r: 23, d: 2.0, snd: '05', name: 'Matilda' },
    hal: { r: 18, d: 2.0, snd: '01', name: 'Hal' },
    terence: { r: 33, d: 2.4, snd: '01', name: 'Terence' },
  };
  const PIGS = {
    small: { w: 48, K: 240 }, medium: { w: 78, K: 280 }, helmet: { w: 93, K: 650 },
    large: { w: 98, K: 330 }, grandpa: { w: 110, K: 380 }, king: { w: 126, K: 480 },
  };

  /* ---------------- state ---------------- */
  const world = new World({ gy: GRAV, iterations: 10 });
  const cam = new Camera(); cam.maxX = WORLD_W;
  const fx = new Particles();
  const G = {
    screen: 'loading', state: 'idle', level: 0, ep: 0, mode: 'campaign', wave: 1, ended: false, slingGone: false, trans: null, arrive: null, queueHidden: false, banner: null, score: 0, queue: [], cur: null, curType: null,
    flying: [], armed: false, paused: false, debug: false, t: 0, calmT: 0, turnT: 0, winT: -1, loseT: -1,
    dragging: false, panning: false, drag: { x: SX, y: SY }, loadAnim: null, pigs: 0, stars: [0, 0, 0], thr: [0, 0],
    totalBirds: 0, soundCD: {},
  };
  let saved = Storage.get('progress', { stars: [] });
  saved.best = saved.best || []; saved.seen = saved.seen || {}; saved.endless = saved.endless || { wave: 0, score: 0 };
  let token = 0;

  /* ---------------- sound utilities ---------------- */
  function sfx(prefix, vol, jitter) {
    const now = performance.now(), cd = G.soundCD;
    if (cd[prefix] && now - cd[prefix] < 70) return;
    cd[prefix] = now;
    Audio.any(prefix, { vol: vol == null ? 1 : vol, jitter: jitter || 0.06 });
  }

  /* ---------------- level construction ---------------- */
  const D = (mat, kind) => { const im = Assets.img(mat + '_' + kind + '_0'); return { w: im.width * S, h: im.height * S }; };
  let blocks = 0, pigPts = 0, blockPts = 0;

  function B(mat, kind, cx, bottom, rot) {
    const m = MAT[mat], d = D(mat, kind), w = d.w, h = d.h;
    const effH = rot ? w : h, cy = bottom - effH / 2;
    const o = { x: cx + OX, y: cy, a: rot ? Math.PI / 2 : 0, density: m.d, friction: m.f, restitution: m.e, kind: 'block' };
    let b;
    if (kind === 'circ') { o.a = 0; o.angDamp = 0.4; b = Body.circle(Object.assign(o, { r: w / 2 * 0.97 })); }
    else if (kind === 'tri') b = Body.triangle(w * 0.98, h * 0.98, o);
    else b = Body.box(w, h, o);
    b.userData = { type: 'block', mat, kind, w, h, imgs: [mat + '_' + kind + '_0', mat + '_' + kind + '_1', mat + '_' + kind + '_2'], hp: b.mass * m.K, maxHp: b.mass * m.K, stage: 0, flash: 0 };
    world.add(b); blocks++; blockPts += m.pts;
    return bottom - effH;
  }
  function tnt(cx, bottom) {
    const im = Assets.img('tnt'), w = im.width * S, h = im.height * S, m = MAT.tnt;
    const b = Body.box(w, h, { x: cx + OX, y: bottom - h / 2, density: m.d, friction: m.f, restitution: m.e, kind: 'block' });
    b.userData = { type: 'block', mat: 'tnt', kind: 'tnt', w, h, imgs: ['tnt', 'tnt', 'tnt'], hp: b.mass * m.K, maxHp: b.mass * m.K, stage: 0, flash: 0 };
    world.add(b); blocks++; blockPts += m.pts; return bottom - h;
  }
  function pig(type, cx, bottom) {
    const P = PIGS[type], im = Assets.img('pig_' + type + '_0'), w = im.width * S, h = im.height * S, r = w * 0.4;
    const b = Body.circle({ x: cx + OX, y: bottom - r, r, density: 0.9, friction: 0.7, restitution: 0.1, angDamp: 1.6, kind: 'pig' });
    b.userData = { type: 'pig', pt: type, w, h, hp: b.mass * P.K, maxHp: b.mass * P.K, slot: 0, blink: U.rand(1, 4), blinkT: 0, react: 0, oink: U.rand(5, 14), flash: 0 };
    world.add(b); G.pigs++; pigPts += 5000;
  }
  // multi-story house: posts and roof
  function house(x, bottom, cfg) {
    let y = bottom;
    for (const f of cfg.floors) {
      const mat = f.mat || cfg.mat, pk = f.post || 'short', ph = D(mat, pk).w, span = f.span || 90;
      B(mat, pk, x - span / 2, y, true); B(mat, pk, x + span / 2, y, true);
      if (f.pig) pig(f.pig, x, y);
      if (f.tnt) tnt(x, y);
      const rw = D(mat, 'plank').w;
      if (span + 14 <= rw) B(mat, 'plank', x, y - ph, false);
      else { B(mat, 'plank', x - rw / 2 + 6, y - ph, false); B(mat, 'plank', x + rw / 2 - 6, y - ph, false); }
      y -= ph + D(mat, 'plank').h;
    }
    return y;
  }

  const LEVELS = [
    { name: 'First Flight', birds: ['red', 'red', 'red'], build() {
      const t = house(1300, GY, { mat: 'wood', floors: [{ post: 'short', pig: 'small' }] });
      B('wood', 'tri', 1300, t, false); pig('small', 1520, GY);
    } },
    { name: 'Twin Houses', birds: ['red', 'red', 'red', 'red'], build() {
      house(1150, GY, { mat: 'wood', floors: [{ post: 'short', pig: 'small' }] });
      house(1400, GY, { mat: 'wood', floors: [{ post: 'plank', pig: 'small' }, { post: 'short' }] });
    } },
    { name: 'Ice Palace', birds: ['red', 'blue', 'blue', 'red'], build() {
      const t = house(1300, GY, { mat: 'ice', floors: [{ post: 'plank', pig: 'medium' }, { post: 'short', pig: 'small' }] });
      B('ice', 'tri', 1300, t, false); pig('small', 1560, GY);
    } },
    { name: 'Stone Base', birds: ['red', 'chuck', 'chuck', 'bomb', 'red'], build() {
      house(1250, GY, { mat: 'wood', floors: [{ post: 'short', pig: 'small' }, { post: 'short' }] });
      house(1500, GY, { mat: 'stone', floors: [{ post: 'short', pig: 'helmet', span: 100 }, { post: 'short', mat: 'wood', pig: 'small' }] });
    } },
    { name: 'TNT Bridge', birds: ['chuck', 'bomb', 'red', 'matilda', 'blue'], build() {
      const a = house(1180, GY, { mat: 'wood', floors: [{ post: 'plank' }] });
      const b = house(1470, GY, { mat: 'ice', floors: [{ post: 'plank' }] });
      pig('medium', 1180, a); pig('small', 1445, b); B('stone', 'cube', 1498, b, false);
      tnt(1325, tnt(1325, GY));
      pig('small', 1650, GY);
    } },
    { name: 'Frozen Fortress', birds: ['blue', 'blue', 'chuck', 'matilda', 'red', 'red'], build() {
      const t = house(1350, GY, { mat: 'ice', floors: [{ post: 'plank', pig: 'medium' }, { post: 'short', pig: 'small' }] });
      B('ice', 'tri', 1350, t, false);
      house(1100, GY, { mat: 'ice', floors: [{ post: 'short', pig: 'small' }] });
      pig('helmet', 1620, GY);
    } },
    { name: 'Stone Castle', birds: ['bomb', 'bomb', 'matilda', 'terence', 'red', 'chuck'], build() {
      house(1350, GY, { mat: 'stone', floors: [{ post: 'plank', pig: 'grandpa', span: 100 }, { post: 'short', pig: 'helmet' }, { post: 'short', mat: 'wood', pig: 'small' }] });
      house(1110, GY, { mat: 'stone', floors: [{ post: 'plank', pig: 'large', span: 100 }] });
      house(1600, GY, { mat: 'wood', floors: [{ post: 'plank', pig: 'medium', tnt: false }] });
    } },
    { name: 'King Pig', birds: ['terence', 'hal', 'chuck', 'bomb', 'matilda', 'red', 'blue'], build() {
      const t = house(1450, GY, { mat: 'stone', floors: [{ post: 'plank', pig: 'king', span: 112 }, { post: 'plank', mat: 'wood', pig: 'large', span: 100 }, { post: 'short', mat: 'ice', pig: 'helmet' }] });
      B('ice', 'tri', 1450, t, false);
      house(1150, GY, { mat: 'wood', floors: [{ post: 'plank', pig: 'medium' }] });
      house(1750, GY, { mat: 'ice', floors: [{ post: 'plank', pig: 'small' }] });
      tnt(1300, GY); tnt(1600, GY);
    } },
  ];

  /* ---------------- birds ---------------- */
  const THEMES = [
    { amb: 'amb_jungle', tint: null }, { amb: 'amb_savannah', tint: null },
    { amb: 'amb_dryforest', tint: null }, { amb: 'amb_construction', tint: null },
    { amb: 'amb_city', tint: null }, { amb: 'amb_dryforest', tint: null },
    { amb: 'amb_city', tint: null }, { amb: 'amb_savannah', tint: null },
  ];
  LEVELS.forEach((L, i) => Object.assign(L, THEMES[i]));
  const MENU_MUSIC = 'amb_construction';

  /* ---------------- episodios ---------------- */
  const EP1_LEVELS = LEVELS.splice(0); // the eight hand-built levels in episode 1
  const EPS = [
    { n: 'Poached Eggs', card: 'u_ep1', btn: 'u_lvbtn1', dl: 'u_ep1_left', dr: 'u_ep1_right', theme: null, levels: EP1_LEVELS },
    { n: 'The Big Setup', card: 'u_ep2', btn: 'u_lvbtn1', dl: 'u_d2_left', dr: 'u_d2_right', theme: 't4', amb: 'amb_savannah' },
    { n: 'Danger Above', card: 'u_ep3', btn: 'u_lvbtn3', dl: 'u_d3_left', dr: 'u_d3_right', theme: 't6', amb: 'amb_jungle' },
    { n: 'The Big Setup', card: 'u_ep4', btn: 'u_lvbtn4', dl: 'u_d4_left', dr: 'u_d4_right', theme: 't7', amb: 'amb_city' },
    { n: 'Ham ’Em High', card: 'u_ep5', btn: 'u_lvbtn2', dl: 'u_ep1_left', dr: 'u_d5_right', theme: 't3', amb: 'amb_dryforest' },
    { n: 'Mine and Dine', card: 'u_ep6', btn: 'u_lvbtn4', dl: 'u_d6_left', dr: 'u_d6_right', theme: 't10', amb: 'amb_construction' },
    { n: 'Birthday Party', card: 'u_ep7', btn: 'u_lvbtn1', dl: 'u_d7_left', dr: 'u_d7_right', theme: 't11', amb: 'amb_savannah' },
    { n: 'Surf and Turf', card: 'u_ep8', btn: 'u_lvbtn1', dl: 'u_d7_left', dr: 'u_d2_right', theme: 't13', amb: 'amb_jungle' },
  ];
  const THEME_META = window.THEME_META || {};

  // level level generator settings for episodes 2–8
  const GEN = {
    1: { mats: { wood: 3, ice: 3, stone: 1 }, birds: ['red', 'blue', 'chuck'], pigs: 0, tnt: 0 },
    2: { mats: { wood: 4, stone: 2, ice: 1 }, birds: ['red', 'chuck', 'bomb'], pigs: 0, tnt: 0 },
    3: { mats: { stone: 3, wood: 3, ice: 1 }, birds: ['bomb', 'matilda', 'chuck', 'red'], pigs: 1, tnt: 0.5 },
    4: { mats: { wood: 4, stone: 2 }, birds: ['hal', 'matilda', 'red', 'chuck'], pigs: 1, tnt: 0 },
    5: { mats: { stone: 3, ice: 3, wood: 1 }, birds: ['bomb', 'terence', 'matilda', 'blue'], pigs: 2, tnt: 0.4 },
    6: { mats: { ice: 3, wood: 3, stone: 1 }, birds: ['matilda', 'blue', 'chuck', 'bomb'], pigs: 1, tnt: 0.5 },
    7: { mats: { wood: 3, ice: 3, stone: 2 }, birds: ['hal', 'terence', 'bomb', 'matilda', 'blue', 'chuck'], pigs: 2, tnt: 0.4 },
  };
  const PIG_ORDER = ['small', 'medium', 'helmet', 'large', 'grandpa'];
  const DENS = { stone: 3, wood: 2, ice: 1 };
  const LEVELS_PER_GEN_EP = 6;
  const ATTEMPT = window.LEVEL_ATTEMPTS || {};

  function mulberry(a) {
    return function () { a |= 0; a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  }
  // Phase 1 creates a deterministic data plan; phase 2 builds it in the world
  function planLevel(ei, li, n, attempt) {
    const C = GEN[ei], rnd = mulberry(ei * 7919 + li * 104729 + attempt * 1299709 + 11), p = li / (n - 1);
    const pickMat = () => { const e = Object.entries(C.mats), tot = e.reduce((s, x) => s + x[1], 0); let r = rnd() * tot; for (const [m, w] of e) { if ((r -= w) < 0) return m; } return e[0][0]; };
    const pickPig = () => { const hi = Math.min(PIG_ORDER.length - 1, C.pigs + Math.floor(p * 3 + rnd() * 1.6)); return PIG_ORDER[Math.max(0, Math.min(hi, C.pigs + Math.floor(rnd() * (1 + p * 2))))]; };
    const nS = 1 + (p > 0.2 ? 1 : 0) + (p > 0.65 ? 1 : 0);
    const xs = nS === 1 ? [1350] : nS === 2 ? [1210, 1530] : [1060, 1340, 1620];
    const plan = { structs: [], ground: [], tnts: [] };
    xs.forEach((x0, si) => {
      const x = x0 + Math.round((rnd() - 0.5) * 50);
      const nf = Math.min(3, 1 + (rnd() < 0.3 + p * 0.5 ? 1 : 0) + (p > 0.55 && rnd() < 0.4 ? 1 : 0));
      const mats = []; for (let f = 0; f < nf; f++) mats.push(pickMat());
      mats.sort((a, b) => DENS[b] - DENS[a]); // heavier materials at the bottom
      const floors = mats.map((mat, f) => {
        const top = f === nf - 1;
        let pig = (top ? rnd() < 0.92 : rnd() < 0.4) ? pickPig() : null;
        if (li === n - 1 && si === 0 && f === 0) pig = 'king';
        const heavy = pig && ['helmet', 'large', 'grandpa', 'king'].includes(pig);
        const o = { mat, post: heavy || rnd() < 0.5 ? 'plank' : 'short', span: pig === 'king' ? 112 : pig === 'grandpa' ? 100 : 90 };
        if (pig) o.pig = pig;
        else if (C.tnt && f === 0 && rnd() < C.tnt * 0.5) o.tnt = true;
        return o;
      });
      plan.structs.push({ x, mat: floors[0].mat, floors, tri: rnd() < 0.45 });
    });
    for (let i = 0; i + 1 < plan.structs.length; i++) {
      const mid = (plan.structs[i].x + plan.structs[i + 1].x) / 2;
      if (rnd() < 0.5 + p * 0.3) plan.ground.push(['small', mid]);
      else if (C.tnt && rnd() < C.tnt) plan.tnts.push(mid);
    }
    if (!plan.structs.some((s) => s.floors.some((f) => f.pig)) && !plan.ground.length) plan.structs[0].floors[plan.structs[0].floors.length - 1].pig = 'medium';
    const pigs = plan.structs.reduce((s, st) => s + st.floors.filter((f) => f.pig).length, 0) + plan.ground.length;
    const count = Math.max(3, Math.min(7, pigs + 2));
    plan.birds = ['red']; while (plan.birds.length < count) plan.birds.push(C.birds[Math.floor(rnd() * C.birds.length)]);
    return plan;
  }
  function makeGenLevel(ei, li, attempt) {
    const plan = planLevel(ei, li, LEVELS_PER_GEN_EP, attempt);
    return {
      name: (ei + 1) + '-' + (li + 1), birds: plan.birds, amb: EPS[ei].amb, tint: null, attempt,
      build() {
        for (const s of plan.structs) {
          const top = house(s.x, GY, { mat: s.mat, floors: s.floors });
          if (s.tri && s.floors.length < 3) B(s.floors[s.floors.length - 1].mat, 'tri', s.x, top);
        }
        for (const [t, x] of plan.ground) pig(t, x, GY);
        for (const x of plan.tnts) tnt(x, GY);
      },
    };
  }
  function makeEpisodeLevels(ei) {
    const out = [];
    for (let li = 0; li < LEVELS_PER_GEN_EP; li++) out.push(makeGenLevel(ei, li, ATTEMPT[(ei + 1) + '-' + (li + 1)] || 0));
    return out;
  }
  EPS.forEach((E, ei) => {
    if (ei > 0) E.levels = makeEpisodeLevels(ei);
    E.levels.forEach((L, li) => { L.ep = ei; L.li = li; LEVELS.push(L); });
  });
  EPS.forEach((E) => { E.first = LEVELS.indexOf(E.levels[0]); });
  function regenLevel(gi, attempt) {
    const L = LEVELS[gi], N = makeGenLevel(L.ep, L.li, attempt);
    Object.assign(L, N, { ep: L.ep, li: L.li });
  }


  function makeBird(type, x, y, vx, vy, group) {
    const t = BIRDS[type];
    const b = Body.circle({ x, y, r: t.r, density: t.d, friction: 0.8, restitution: 0.2, angDamp: 0.9, rollResist: 4, linDamp: 0, group: group || 0, kind: 'bird', vx, vy });
    b.userData = { type: 'bird', bt: type, age: 0, still: 0, used: false, hit: false, fuse: -1, fade: -1, w: Assets.img('bird_' + type).width * BS, h: Assets.img('bird_' + type).height * BS };
    world.add(b); return b;
  }
  function birdSprite(type) { return Assets.img('bird_' + type); }

  function loadNextBird() {
    if (!G.queue.length) { G.cur = null; return; }
    const type = G.queue.shift();
    G.curType = type; G.cur = null;
    const from = { x: SX - 60 - 0 * 38, y: GY - BIRDS[type].r };
    G.loadAnim = { t: 0, from, type };
    G.state = 'loading';
    sfx('bird_next_military_a', 0.8, 0);
  }

  function launch() {
    const type = G.curType, d = G.drag;
    const vx = (SX - d.x) * KPOW, vy = (SY - d.y) * KPOW;
    const b = makeBird(type, d.x, d.y, vx, vy, 0);
    G.flying = [b]; G.cur = null; G.curType = null; G.state = 'flying'; G.turnT = 0; G.calmT = 0; G.follow = true;
    sfx('bird_shot-a', 1, 0.04);
    setTimeout(() => sfx('bird_' + BIRDS[type].snd + '_flying', 0.6, 0.04), 80);
    updateBirdCount();
  }

  function ability(b) {
    const u = b.userData; if (!u || u.used || u.dead) return;
    u.used = true;
    if (u.bt === 'red' || u.bt === 'terence') { sfx('redbird_yell0', 0.9, 0.05); return; }
    if (u.bt === 'blue') {
      sfx('bird_02_select', 0.8);
      const g = b.id; b.group = g;
      for (const s of [-0.28, 0.28]) {
        const c = Math.cos(s), si = Math.sin(s);
        const nb = makeBird('blue', b.x, b.y + s * 20, b.vx * c - b.vy * si, b.vx * si + b.vy * c, g);
        nb.userData.used = true; G.flying.push(nb);
      }
      fx.burst(b.x, b.y, 8, { color: ['#7cc8ff', '#fff'], size: 4, life: 0.4, gravity: 0, maxSpeed: 120 });
    } else if (u.bt === 'chuck') {
      sfx('special_boost', 1);
      const sp = Math.hypot(b.vx, b.vy) || 1, ns = Math.max(sp * 2.2, 1250);
      b.vx = b.vx / sp * ns; b.vy = b.vy / sp * ns;
      fx.burst(b.x, b.y, 10, { color: ['#ffe14a', '#fff'], size: 4, life: 0.4, gravity: 0, maxSpeed: 200 });
    } else if (u.bt === 'bomb') { explodeBird(b); }
    else if (u.bt === 'matilda') {
      sfx('bird_pushing_egg_out', 1);
      const egg = Body.circle({ x: b.x, y: b.y + 14, r: 10, density: 2, friction: 0.5, restitution: 0.2, kind: 'egg', vx: b.vx * 0.3, vy: 120, group: b.id });
      egg.userData = { type: 'egg', age: 0 };
      b.group = b.id; world.add(egg);
      b.vy = -460; b.vx = b.vx * 1.15;
    } else if (u.bt === 'hal') {
      sfx('boomerang_activate', 1);
      b.vx = -b.vx * 0.95; b.vy = Math.min(b.vy * 0.2, 0) - 140;
    }
  }

  /* ---------------- explosions and damage ---------------- */
  function explode(x, y, radius, dmg, snd) {
    sfx(snd || 'tnt_box_explodes', 1, 0.03);
    const hits = world.explode(x, y, radius, 650);
    for (const { body, k } of hits) hurt(body, dmg * k, true);
    fx.burst(x, y, 22, { color: ['#ffd23a', '#ff8a1f', '#fff3b0'], size: 11, life: 0.55, gravity: -40, maxSpeed: radius * 2.2, drag: 3, grow: 14 });
    fx.burst(x, y, 14, { color: ['#555', '#777', '#999'], size: 12, life: 0.9, gravity: -60, maxSpeed: radius * 1.2, drag: 2, grow: 10, alpha: 0.7 });
    shake = Math.max(shake, 10);
  }
  function explodeBird(b) {
    if (b.userData.dead) return; b.userData.dead = true; world.remove(b);
    explode(b.x, b.y, 135, 1300000);
  }
  let shake = 0;

  function popup(x, y, pts, col) { G.score += pts; fx.text(x, y, String(pts), { color: col || '#fff', size: 24 }); $('score').textContent = G.score.toLocaleString('en-US'); }

  function hurt(b, amt, force) {
    const u = b.userData; if (!u || u.dead || u.hp === undefined) return;
    u.hp -= amt; u.flash = 0.18;
    if (u.hp <= 0) { kill(b); return; }
    const ratio = u.hp / u.maxHp;
    if (u.type === 'block') {
      const st = ratio > 0.66 ? 0 : ratio > 0.33 ? 1 : 2;
      if (st > u.stage) { u.stage = st; sfx(MAT[u.mat].dm, 0.9); popup(b.x, b.y - 10, 100, '#ffe'); }
    } else if (u.type === 'pig') {
      u.react = 0.6; sfx('piglette_damage_a', 0.9);
    }
  }
  function kill(b) {
    const u = b.userData; if (u.dead) return; u.dead = true; world.remove(b);
    if (u.type === 'block') {
      const m = MAT[u.mat];
      sfx(m.ds, 1, 0.05);
      fx.burst(b.x, b.y, 12, { color: m.col, size: 7, life: 0.9, shape: 'rect', maxSpeed: 260, up: 120, gravity: 900 });
      popup(b.x, b.y - 14, m.pts, '#fff');
      if (u.mat === 'tnt') explode(b.x, b.y, 150, 1500000);
    } else if (u.type === 'pig') {
      sfx('piglette_destroyed', 1);
      fx.burst(b.x, b.y, 16, { color: ['#8de35a', '#c9f59b', '#fff'], size: 9, life: 0.7, maxSpeed: 240, gravity: 200, drag: 2 });
      fx.burst(b.x, b.y, 8, { color: ['#eee', '#ccc'], size: 12, life: 0.8, maxSpeed: 120, gravity: -30, drag: 2, grow: 10, alpha: 0.8 });
      popup(b.x, b.y - 20, 5000, '#9f6');
      if (!u.kamikaze) G.pigs--;
    }
  }

  const THR = { block: 120, pig: 90 };
  world.onImpact = (A, B2, imp, cl, x, y, isNew) => {
    if (!G.armed) return;
    const ua = A.userData, ub = B2.userData;
    if (ua && ua.dead || ub && ub.dead) return;
    const vol = U.clamp(cl / 500, 0.2, 1);
    // Matilda egg
    for (const [e, o] of [[A, B2], [B2, A]]) {
      if (e.userData && e.userData.type === 'egg' && !e.userData.dead && (cl > 40 || isNew)) {
        e.userData.dead = true; world.remove(e); sfx('special_egg_explosion', 1);
        explode(e.x, e.y, 100, 1000000, 'special_egg_explosion'); return;
      }
    }
    // sonidos
    for (const b of [A, B2]) {
      const u = b.userData; if (!u || cl < 60) continue;
      if (u.type === 'block') sfx(MAT[u.mat].col_, vol * 0.8);
      else if (u.type === 'pig') sfx('piglette_collision_a', vol);
      else if (u.type === 'bird') {
        const nowT = performance.now(); if (!u.sndT || nowT - u.sndT > 250) { u.sndT = nowT; Audio.any('bird_' + BIRDS[u.bt].snd + '_collision_a', { vol, jitter: 0.05 }); }
      }
    }
    // mark bird impact
    for (const b of [A, B2]) { const u = b.userData; if (u && u.type === 'bird' && cl > 60) { u.hit = true; if (u.bt === 'bomb' && u.fuse < 0) u.fuse = 1.2; } }
    // damage
    for (const [b, o] of [[A, B2], [B2, A]]) {
      const u = b.userData; if (!u || u.hp === undefined) continue;
      const thr = u.type === 'pig' ? THR.pig : THR.block;
      if (cl < thr) continue;
      const ou = o.userData;
      const k = o.static ? 0.5 : ou && ou.type === 'bird' ? 1 : 0.7;
      hurt(b, imp * k);
    }
  };

  /* ---------------- level loading ---------------- */
  function startLevel(i) {
    G.mode = 'campaign'; G.ended = false; G.slingGone = false; G.trans = null; G.arrive = null; G.queueHidden = false; G.banner = null; G.endlessOver = false;
    G.level = i; G.ep = LEVELS[i].ep; const L = LEVELS[i];
    world.clear(); fx.list.length = 0; fx.texts.length = 0;
    world.add(Body.box(WORLD_W + 4000, 300, { x: WORLD_W / 2, y: GY + 150, static: true, friction: 0.8, restitution: 0.05, kind: 'ground' }).setStatic());
    world.add(Body.box(100, 4000, { x: -50, y: GY - 1500, static: true }).setStatic());
    G.pigs = 0; blocks = 0; pigPts = 0; blockPts = 0; G.armed = false; G.score = 0;
    L.build();
    for (let k = 0; k < 150; k++) world.step(1 / 120);
    G.armed = true;
    G.queue = L.birds.slice(); G.totalBirds = L.birds.length; G.flying = []; G.cur = null; G.curType = null;
    G.winT = -1; G.loseT = -1; G.paused = false;
    G.thr = [pigPts + 0.3 * blockPts, pigPts + 0.5 * blockPts + 10000 * Math.max(1, L.birds.length - 2)];
    $('score').textContent = '0';
    cam.x = 0; cam.y = 0; setScreen('game');
    updateBirdCount();
    sfx('level_start_military_a', 0.9, 0); G.state = 'intro';
    token++; G.introT = 0; G.tint = L.tint; Audio.music(L.amb);
  }

  /* ---------------- modo Endless ---------------- */
  const ALL_BIRDS = ['red', 'blue', 'chuck', 'bomb', 'matilda', 'hal', 'terence'];
  function planEndless(w, seed) {
    const rnd = mulberry(w * 7919 + seed * 1299709 + 5);
    const nS = Math.min(3, 1 + Math.floor((w + 1) / 3));
    const xs = nS === 1 ? [1350] : nS === 2 ? [1210, 1530] : [1060, 1340, 1620];
    const mw = { wood: Math.max(1.2, 4 - w * 0.25), ice: Math.max(1, 3 - w * 0.15), stone: 1 + w * 0.4 };
    const pickMat = () => { const e = Object.entries(mw), tot = e.reduce((s, x) => s + x[1], 0); let r = rnd() * tot; for (const [m, v] of e) { if ((r -= v) < 0) return m; } return 'wood'; };
    const cap = Math.min(4, Math.floor(w / 2));
    const pickPig = () => PIG_ORDER[Math.min(cap, Math.floor(rnd() * (cap + 1) + (rnd() < 0.5 ? 0.5 : 0)))];
    const plan = { structs: [], ground: [], tnts: [] };
    xs.forEach((x0, si) => {
      const x = x0 + Math.round((rnd() - 0.5) * 50);
      const nf = Math.min(3, 1 + (rnd() < 0.35 + w * 0.05 ? 1 : 0) + (w > 4 && rnd() < 0.4 ? 1 : 0));
      const mats = []; for (let f = 0; f < nf; f++) mats.push(pickMat());
      mats.sort((a, b) => DENS[b] - DENS[a]);
      const floors = mats.map((mat, f) => {
        const top = f === nf - 1;
        let pig = (top ? rnd() < 0.92 : rnd() < 0.4) ? pickPig() : null;
        if (w % 5 === 0 && si === 0 && f === 0) pig = 'king';
        const heavy = pig && ['helmet', 'large', 'grandpa', 'king'].includes(pig);
        const o = { mat, post: heavy || rnd() < 0.5 ? 'plank' : 'short', span: pig === 'king' ? 112 : pig === 'grandpa' ? 100 : 90 };
        if (pig) o.pig = pig; else if (f === 0 && rnd() < 0.15) o.tnt = true;
        return o;
      });
      plan.structs.push({ x, mat: floors[0].mat, floors, tri: rnd() < 0.4 });
    });
    for (let i = 0; i + 1 < plan.structs.length; i++) {
      const mid = (plan.structs[i].x + plan.structs[i + 1].x) / 2;
      if (rnd() < 0.55) plan.ground.push([rnd() < 0.5 ? 'small' : 'medium', mid]); else if (rnd() < 0.3) plan.tnts.push(mid);
    }
    if (!plan.structs.some((s) => s.floors.some((f) => f.pig)) && !plan.ground.length) plan.structs[0].floors[plan.structs[0].floors.length - 1].pig = 'medium';
    const pigs = plan.structs.reduce((s, st) => s + st.floors.filter((f) => f.pig).length, 0) + plan.ground.length;
    const count = Math.max(3, Math.min(7, pigs + 2));
    plan.birds = ['red']; while (plan.birds.length < count) plan.birds.push(ALL_BIRDS[Math.floor(rnd() * ALL_BIRDS.length)]);
    return plan;
  }
  function execPlan(plan) {
    for (const s of plan.structs) {
      const top = house(s.x, GY, { mat: s.mat, floors: s.floors });
      if (s.tri && s.floors.length < 3) B(s.floors[s.floors.length - 1].mat, 'tri', s.x, top);
    }
    for (const [t, x] of plan.ground) pig(t, x, GY);
    for (const x of plan.tnts) tnt(x, GY);
  }
  function addGround() {
    world.add(Body.box(WORLD_W + 4000, 300, { x: WORLD_W / 2, y: GY + 150, static: true, friction: 0.8, restitution: 0.05, kind: 'ground' }).setStatic());
    world.add(Body.box(100, 4000, { x: -50, y: GY - 1500, static: true }).setStatic());
  }
  function buildWave(w) {
    let plan, ok = false;
    for (let tries = 0; tries < 8 && !ok; tries++) {
      plan = planEndless(w, tries + (G.endSeed || 0));
      world.clear(); addGround(); G.pigs = 0; blocks = 0; pigPts = 0; blockPts = 0; G.armed = false;
      execPlan(plan);
      for (let k = 0; k < 150; k++) world.step(1 / 120);
      const snap = new Map(world.bodies.filter((b) => !b.static).map((b) => [b.id, [b.x, b.y]]));
      for (let k = 0; k < 120; k++) world.step(1 / 120);
      ok = G.pigs > 0 && world.bodies.every((b) => b.static || (snap.has(b.id) && Math.hypot(b.x - snap.get(b.id)[0], b.y - snap.get(b.id)[1]) < 10));
    }
    G.armed = true; G.queue = plan.birds.slice(); G.totalBirds = plan.birds.length; G.flying = []; G.cur = null; G.curType = null;
    G.ep = (w - 1) % EPS.length; G.tint = null; Audio.music(EPS[G.ep].amb || MENU_MUSIC);
    G.winT = -1; G.loseT = -1; G.paused = false; G.ended = false; G.endlessOver = false;
  }
  function startEndless() {
    G.mode = 'endless'; G.wave = 1; G.score = 0; G.endSeed = (Math.random() * 1000) | 0;
    G.slingGone = false; G.trans = null; G.arrive = null; G.queueHidden = false; G.banner = null;
    fx.list.length = 0; fx.texts.length = 0;
    buildWave(1);
    G.level = 0; $('score').textContent = '0'; cam.x = 0; cam.y = 0; setScreen('game'); updateBirdCount();
    sfx('level_start_military_a', 0.9, 0); G.state = 'intro'; token++; G.introT = 0;
    G.banner = { text: 'Wave 1', t: 0 };
  }
  function queueXs(n, types) { const xs = []; let qx = SX - 50; for (const t of types.slice(0, 5)) { const w = birdSprite(t).width * BS; qx -= w * 0.4; xs.push(qx); qx -= w * 0.4 + 2; } return xs; }
  function beginTransition() {
    if (G.curType) { G.queue.unshift(G.curType); G.cur = null; G.curType = null; }
    G.ended = true; G.state = 'trans'; G.trans = { ph: 0, t: 0, pig: null, fuse: -1 };
    const left = G.queue.length; if (left) popup(SX, SY - 60, left * 10000, '#ffe08a');
    G.banner = { text: 'Wave ' + G.wave + ' cleared!', t: 0 };
    if (G.wave > saved.endless.wave) { saved.endless.wave = G.wave; }
    if (G.score > saved.endless.score) saved.endless.score = G.score;
    Storage.set('progress', saved);
    sfx('level_clear_military_a', 1, 0);
  }
  function slingExplode() {
    sfx('tnt_box_explodes', 1, 0.03);
    fx.burst(SX, SY + 20, 26, { color: ['#8a5a2b', '#5a3516', '#ffd23a', '#ff8a1f'], size: 9, life: 0.9, shape: 'rect', maxSpeed: 360, up: 160, gravity: 900 });
    fx.burst(SX, SY + 20, 16, { color: ['#555', '#888'], size: 14, life: 1, gravity: -50, maxSpeed: 160, drag: 2, grow: 12, alpha: 0.7 });
    shake = Math.max(shake, 14); G.slingGone = true;
  }
  function spawnKamikaze() {
    const P = PIGS.helmet, im = Assets.img('pig_helmet_0'), w = im.width * S, h = im.height * S, r = w * 0.4;
    const b = Body.circle(SX + 190, -80, r, { density: 0.9, friction: 0.7, restitution: 0.1, angDamp: 1.6, kind: 'pig' });
    b.userData = { type: 'pig', pt: 'helmet', w, h, hp: 1e12, maxHp: 1e12, slot: 0, blink: 9, blinkT: 0, react: 0, oink: 99, flash: 0, kamikaze: true };
    world.add(b); G.trans.pig = b; sfx('piglette_oink_a', 1, 0.05);
  }
  function updateTrans(dt) {
    const T = G.trans; T.t += dt;
    if (T.ph === 0 && T.t > 1.8) { T.ph = 1; T.t = 0; slingExplode(); }
    else if (T.ph === 1 && T.t > 1.0) { T.ph = 2; T.t = 0; spawnKamikaze(); }
    else if (T.ph === 2) {
      const p = T.pig;
      if (p && !p.dead && T.fuse < 0) {
        if (p.y > GY - p.r - 4) p.vx = -170;               // walks toward the slingshot debris
        if ((p.x < SX + 70 && p.y > GY - p.r - 6) || T.t > 6) { T.fuse = 1.1; sfx('bird_destroyed', 0.6, 0.1); }
      } else if (p && T.fuse >= 0) {
        T.fuse -= dt; p.userData.flash = 0.2;
        if (T.fuse < 0) {
          // the explosion kills the pig and any remaining birds
          sfx('tnt_box_explodes', 1, 0.03); shake = Math.max(shake, 16);
          explodeAt(p.x, p.y, 200);
          queueXs(G.queue.length, G.queue).forEach((x) => { fx.burst(x, GY - 20, 14, { color: ['#d33', '#fff', '#fa0'], size: 6, life: 0.8, maxSpeed: 280, up: 120, gravity: 700 }); sfx('bird_destroyed', 0.7, 0.1); });
          G.queue = []; updateBirdCount();
          p.userData.dead = true; world.remove(p);
          T.ph = 3; T.t = 0;
        }
      }
    } else if (T.ph === 3 && T.t > 1.2) { startNextWave(); }
  }
  function explodeAt(x, y, radius) {
    fx.burst(x, y, 24, { color: ['#ffd23a', '#ff8a1f', '#fff3b0'], size: 12, life: 0.6, gravity: -40, maxSpeed: radius * 2, drag: 3, grow: 14 });
    fx.burst(x, y, 14, { color: ['#555', '#777', '#999'], size: 13, life: 1, gravity: -60, maxSpeed: radius * 1.1, drag: 2, grow: 10, alpha: 0.7 });
  }
  function startNextWave() {
    G.wave++; G.trans = null; G.slingGone = false; G.slingPop = 0;
    buildWave(G.wave);
    const xs = queueXs(G.queue.length, G.queue);
    G.arrive = { t: 0, list: G.queue.slice(0, 5).map((type, i) => ({ type, x: xs[i], y0: 90 + ((i * 53) % 160), d: i * 0.28 })) };
    G.queueHidden = true; G.state = 'arriving'; G.ended = false;
    G.banner = { text: 'Wave ' + G.wave, t: 0 }; updateBirdCount(); sfx('level_start_military_a', 0.9, 0);
  }
  function updateArrive(dt) {
    const A = G.arrive; A.t += dt; G.slingPop = Math.min(1, (G.slingPop || 0) + dt / 0.6);
    const done = A.list.every((b) => A.t >= b.d + 1.7);
    if (done) { G.queueHidden = false; G.arrive = null; G.state = 'idle'; const tk = token; setTimeout(() => { if (G.screen === 'game' && tk === token && G.mode === 'endless' && G.state === 'idle') loadNextBird(); }, 300); }
  }
  function drawArrivals() {
    const A = G.arrive; if (!A) return;
    for (const b of A.list) {
      const k = clamp((A.t - b.d) / 1.7, 0, 1); if (A.t < b.d) continue;
      const e = 1 - Math.pow(1 - k, 2), x = lerp(-120, b.x, e), y = lerp(b.y0, GY - BIRDS[b.type].r, k * k) - Math.sin(Math.PI * k) * 70;
      const im = birdSprite(b.type); ctx.save(); ctx.translate(x, y); ctx.rotate(Math.sin(A.t * 16 + b.d * 9) * 0.18 * (1 - k)); ctx.drawImage(im, -im.width * BS / 2, -im.height * BS / 2, im.width * BS, im.height * BS); ctx.restore();
    }
  }
  function drawBanner() {
    const B2 = G.banner; if (!B2) return; B2.t += 1 / 60; if (B2.t > 2.6) { G.banner = null; return; }
    const a = B2.t < 0.3 ? B2.t / 0.3 : B2.t > 2.1 ? 1 - (B2.t - 2.1) / 0.5 : 1;
    ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalAlpha = Math.max(0, a); ctx.textAlign = 'center'; ctx.lineJoin = 'round';
    const fs = Math.round(cv.height * 0.09 * (1 + 0.15 * Math.max(0, 1 - B2.t * 4)));
    ctx.font = fs + 'px ' + FONT; ctx.lineWidth = fs * 0.12; ctx.strokeStyle = '#1d2c4a'; ctx.strokeText(B2.text, cv.width / 2, cv.height * 0.28);
    ctx.fillStyle = '#fff'; ctx.fillText(B2.text, cv.width / 2, cv.height * 0.28); ctx.restore();
  }
  function showEndlessOver() {
    G.state = 'done'; G.winT = G.loseT = -1; G.ended = true; G.endlessOver = true;
    const waves = G.wave - 1;
    if (G.wave - 1 > saved.endless.wave) saved.endless.wave = G.wave - 1; if (G.score > saved.endless.score) saved.endless.score = G.score; Storage.set('progress', saved);
    sfx('level_failed_piglets_a', 1, 0);
    $('endTitle').textContent = 'Game Over!'; $('stars').innerHTML = '<div class="bigWave">' + waves + '<small>waves cleared</small></div>';
    $('endScore').innerHTML = 'Score: <b>' + G.score.toLocaleString('en-US') + '</b><br><small>Best: ' + saved.endless.wave + ' waves · ' + saved.endless.score.toLocaleString('en-US') + ' points</small>';
    $('bNext').style.display = 'none'; $('bFinal').style.display = 'none'; $('end').classList.remove('hidden');
  }

  function updateBirdCount() {
    const left = G.queue.length + (G.curType ? 1 : 0);
    $('birdsLeft').textContent = (G.mode === 'endless' ? 'Wave ' + G.wave + '  ·  ' : '') + '🐦 ' + left;
  }

  /* ---------------- entrada ---------------- */
  let lastP = null;
  new Input(cv, {
    down(sx, sy) {
      Audio.unlock().then(() => Audio.music(MENU_MUSIC));
      if (G.screen !== 'game' || G.paused || G.state === 'trans' || G.state === 'arriving') return;
      const p = cam.toWorld(sx, sy);
      if (G.state === 'ready') {
        if (U.dist(p.x, p.y, SX, SY) < 70) { G.dragging = true; G.drag = { x: SX, y: SY }; sfx('slingshot_streched', 0.8); sfx('bird_' + BIRDS[G.curType].snd + '_select', 0.9); }
        else { G.panning = true; lastP = sx; }
      } else if (G.state === 'flying') {
        G.follow = true;
        for (const b of G.flying.slice()) if (!b.dead) ability(b);
      } else { G.panning = true; lastP = sx; G.follow = false; }
    },
    move(sx, sy) {
      if (G.dragging) {
        const p = cam.toWorld(sx, sy);
        let dx = p.x - SX, dy = p.y - SY; const d = Math.hypot(dx, dy);
        if (d > MAXD) { dx *= MAXD / d; dy *= MAXD / d; }
        if (dx > 15) dx = 15;
        G.drag = { x: SX + dx, y: Math.min(SY + dy, GY - BIRDS[G.curType].r - 2) };
      } else if (G.panning && lastP != null) {
        cam.x -= (sx - lastP) / cam.scale; lastP = sx; cam.clamp();
      }
    },
    up() {
      if (G.dragging) {
        G.dragging = false;
        const d = Math.hypot(G.drag.x - SX, G.drag.y - SY);
        if (d > 18) launch(); else G.drag = { x: SX, y: SY };
      }
      G.panning = false; lastP = null;
    },
    key(k) {
      if (k === 'p' || k === 'P') togglePause();
      if (k === 'd' || k === 'D') G.debug = !G.debug;
      if (k === 'r' || k === 'R') { if (G.screen === 'game') startLevel(G.level); }
    },
  });

  /* ---------------- update ---------------- */
  function update(dt) {
    G.t += dt;
    if (G.screen === 'cutscene') { tickCut(dt); return; }
    if (G.screen !== 'game' || G.paused) return;
    world.step(dt);
    fx.update(dt);
    shake *= 0.9;
    // object animations
    for (const b of world.bodies) {
      const u = b.userData; if (!u) continue;
      if (u.flash > 0) u.flash -= dt;
      if (u.type === 'pig') {
        if (u.react > 0) u.react -= dt;
        u.blink -= dt; if (u.blink < 0) { u.blinkT = 0.14; u.blink = U.rand(2, 5); }
        if (u.blinkT > 0) u.blinkT -= dt;
        u.oink -= dt; if (u.oink < 0) { u.oink = U.rand(7, 16); if (!b.asleep || Math.random() < 0.5) sfx('piglette_oink_a', 0.5, 0.1); }
      }
      if (u.type === 'bird') {
        u.age += dt;
        if (u.fuse >= 0) { u.fuse -= dt; if (u.fuse < 0) { explodeBird(b); continue; } }
        if (u.fade >= 0) { u.fade -= dt; if (u.fade < 0) { fx.burst(b.x, b.y, 8, { color: ['#fff', '#ddd'], size: 7, life: 0.5, gravity: 0, maxSpeed: 90, drag: 2 }); world.remove(b); u.dead = true; } }
      }
      if (u.type === 'egg') { u.age += dt; if (u.age > 6) { u.dead = true; world.remove(b); } }
      if (b.y > GY + 600 || b.x > WORLD_W + 500) { if (u.type === 'pig') { kill(b); } else { u.dead = true; world.remove(b); } }
    }
    G.flying = G.flying.filter((b) => !b.userData.dead);

    if (G.state === 'loading') {
      const a = G.loadAnim; a.t += dt / 0.5;
      if (a.t >= 1) { G.cur = a.type; G.state = 'ready'; G.drag = { x: SX, y: SY }; G.loadAnim = null; sfx('bird_' + BIRDS[a.type].snd + '_select', 0.5); }
    } else if (G.state === 'intro') {
      G.introT += dt;
      let mx = 0; for (const b of world.bodies) if (!b.static && b.x > mx) mx = b.x;
      const tx = Math.max(0, mx + 120 - cam.vw / cam.scale);
      cam.x += ((G.introT < 1.5 ? tx : 0) - cam.x) * Math.min(1, dt * 2.5); cam.clamp();
      if (G.introT > 2.2) loadNextBird();
    } else if (G.state === 'trans') { updateTrans(dt);
    } else if (G.state === 'arriving') { updateArrive(dt);
    } else if (G.state === 'flying') {
      G.turnT += dt;
      // camera path
      const lead = G.flying.reduce((m, b) => (b.x > m ? b.x : m), -1e9);
      if (G.follow && lead > -1e8) { const tx = lead - cam.vw / cam.scale * 0.4; cam.x += (tx - cam.x) * Math.min(1, dt * 3); cam.clamp(); }
      // birds detenidos se desvanecen
      for (const b of G.flying) {
        const u = b.userData;
        if (b.speed() < 25 && (u.hit || b.asleep)) u.still += dt; else u.still = 0;
        if (u.still > 1.0 && u.fade < 0) u.fade = 1.2;
      }
      // calma general
      let moving = 0;
      for (const b of world.bodies) if (!b.static && !b.asleep && b.userData && b.userData.type !== 'bird' && b.speed() > 28) moving++;
      const birdsActive = G.flying.some((b) => !b.userData.dead && b.userData.fade < 0 && !(b.userData.still > 0.6));
      if (moving === 0 && !birdsActive) G.calmT += dt; else G.calmT = 0;
      if (G.calmT > 1.0 || G.turnT > 14) endTurn();
    }
    // victoria / derrota
    if (G.pigs <= 0 && G.winT < 0 && G.armed && G.screen === 'game' && !G.ended) { G.winT = 2.2; }
    if (G.winT >= 0) { G.winT -= dt; if (G.winT < 0) { if (G.mode === 'endless') beginTransition(); else { G.ended = true; showEnd(true); } } }
    if (G.loseT >= 0) { G.loseT -= dt; if (G.loseT < 0 && G.pigs > 0) { if (G.mode === 'endless') showEndlessOver(); else showEnd(false); } }
    G.follow = G.follow && G.state === 'flying';
    if (G.state === 'ready' && !G.dragging && !G.panning) cam.x += (0 - cam.x) * Math.min(1, dt * 2.5);
    if (G.state === 'loading') cam.x += (0 - cam.x) * Math.min(1, dt * 3);
  }
  function endTurn() {
    for (const b of G.flying) if (!b.userData.dead) b.userData.fade = Math.min(b.userData.fade < 0 ? 9 : b.userData.fade, 0.6);
    G.flying = [];
    if (G.pigs <= 0) { G.state = 'done'; return; }
    if (G.queue.length) { G.state = 'idle'; const tk = token; setTimeout(() => { if (G.screen === 'game' && tk === token) loadNextBird(); }, 700); updateBirdCount(); }
    else { G.state = 'done'; G.loseT = 1.2; }
  }

  /* ---------------- level complete ---------------- */
  function showEnd(win) {
    if (G.screen !== 'game') return;
    G.state = 'done'; G.winT = -1; G.loseT = -1;
    const left = G.queue.length + (G.curType ? 1 : 0);
    let bonus = 0, stars = 0;
    if (win) {
      bonus = left * 10000; G.score += bonus; $('score').textContent = G.score.toLocaleString('en-US');
      stars = G.score >= G.thr[1] ? 3 : G.score >= G.thr[0] ? 2 : 1;
      const prev = saved.stars[G.level] || 0;
      if (stars > prev) saved.stars[G.level] = stars;
      if (G.score > (saved.best[G.level] || 0)) saved.best[G.level] = G.score;
      Storage.set('progress', saved);
      sfx('level_clear_military_a', 1, 0);
    } else sfx('level_failed_piglets_a', 1, 0);
    $('endTitle').textContent = win ? 'Level Complete!' : 'Level Failed!';
    $('endScore').innerHTML = 'Score: <b>' + G.score.toLocaleString('en-US') + '</b>' + (bonus ? '<br><small>+' + bonus.toLocaleString('en-US') + ' for unused birds</small>' : '');
    const st = $('stars'); st.innerHTML = '';
    [['l', 'u_star_l', 'u_star_l_e'], ['m', 'u_star_m', 'u_star_m_e'], ['r', 'u_star_r', 'u_star_r_e']].forEach(([c, on, off], i) => {
      const im = document.createElement('img'); const lit = i < stars;
      im.className = c + ' ' + (lit ? 'on' : 'off'); im.src = window.IMGS[lit ? on : off]; im.alt = '';
      if (lit) { im.style.animationDelay = 0.3 + i * 0.35 + 's'; im.style.opacity = 0; setTimeout(() => sfx('star_collect', 0.8, 0), 300 + i * 350); }
      st.appendChild(im);
    });
    $('bNext').style.display = win && LEVELS[G.level + 1] && LEVELS[G.level + 1].ep === G.ep ? '' : 'none';
    $('bFinal').style.display = win && G.level === EP1_LEVELS.length - 1 ? '' : 'none';
    $('end').classList.remove('hidden');
  }

  /* ---------------- rendering ---------------- */
  const gimg = (n) => Assets.img(n);
  function drawTrees(name, par, k, gs) {
    const t = gimg(name); if (!t) return;
    const sc = cam.scale, tw = t.width * k * sc * 0.9, th = t.height * k * sc * 0.9;
    const off = cam.x * par * sc, n0 = Math.floor(off / tw), x0 = -(off - n0 * tw);
    for (let i = 0; x0 + i * tw < cv.width + tw; i++) {
      const n = n0 + i, x = x0 + i * tw, y = gs - th + 8 * sc;
      if (((n % 2) + 2) % 2) { ctx.save(); ctx.translate(x + tw, y); ctx.scale(-1, 1); ctx.drawImage(t, 0, 0, tw + 1, th); ctx.restore(); }
      else ctx.drawImage(t, x, y, tw + 1, th);
    }
  }
  const curEp = () => EPS[(G.screen === 'game' || G.screen === 'levels') ? G.ep : 0];
  const curTheme = () => { const e = curEp(); return e.theme && THEME_META[e.theme] ? { k: e.theme, m: THEME_META[e.theme] } : null; };
  function drawLayer(name, par, bottom) {
    const im = gimg(name); if (!im) return;
    const sc = cam.scale, tw = cv.width * 1.0, th = tw * im.height / im.width;
    const off = cam.x * par * sc, n0 = Math.floor(off / tw), x0 = -(off - n0 * tw), y = bottom - th;
    for (let i = 0; x0 + i * tw < cv.width + tw; i++) {
      const n = n0 + i, x = x0 + i * tw;
      if (((n % 2) + 2) % 2) { ctx.save(); ctx.translate(x + tw, y); ctx.scale(-1, 1); ctx.drawImage(im, 0, 0, tw + 1, th); ctx.restore(); }
      else ctx.drawImage(im, x, y, tw + 1, th);
    }
  }
  function drawThemeBG(T) {
    const w = cv.width, h = cv.height, sc = cam.scale, gs = (GY - cam.y) * sc, M = T.m;
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.fillStyle = M.skyColor; ctx.fillRect(0, 0, w, h);
    const sk = gimg(T.k + '_sky');
    if (sk) {
      const bottom = gs + 30 * sc, s = Math.max(w / sk.width * 1.05, bottom / sk.height), sw = sk.width * s, sh = sk.height * s;
      ctx.drawImage(sk, -(sw - w) * 0.5 - cam.x * sc * 0.02, bottom - sh, sw, sh);
    }
    for (const L of M.layers) drawLayer(T.k + '_' + L.k, L.par, gs + 6 * sc);
  }
  function drawBackground() {
    const TT = curTheme(); if (TT) { drawThemeBG(TT); return; }
    const w = cv.width, h = cv.height, sc = cam.scale, gs = (GY - cam.y) * sc;
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.fillStyle = '#bfe8fb'; ctx.fillRect(0, 0, w, h);
    const sk = gimg('bg_sky');
    if (sk) {
      const s = Math.max(w / sk.width, gs / sk.height) * 1.06, sw = sk.width * s, sh = sk.height * s;
      ctx.drawImage(sk, -(sw - w) * 0.5 - cam.x * sc * 0.02, gs - sh, sw, sh);
    }
    // nubes suaves
    ctx.fillStyle = 'rgba(255,255,255,0.45)';
    for (let i = 0; i < 9; i++) {
      const span = WORLD_W * 0.6 + 400, bx = ((i * 337 + 80 - cam.x * 0.12 + G.t * (4 + i)) % span + span) % span - 200;
      const cx = bx * sc, cy = (60 + (i * 53) % 190) * sc, r = (22 + (i * 7) % 16) * sc;
      ctx.beginPath(); ctx.arc(cx, cy, r, 0, TAU); ctx.arc(cx + r * 1.1, cy + r * 0.2, r * 0.8, 0, TAU); ctx.arc(cx - r * 1.1, cy + r * 0.3, r * 0.7, 0, TAU); ctx.arc(cx + r * 0.2, cy - r * 0.4, r * 0.8, 0, TAU); ctx.fill();
    }
    drawTrees('bg_trees_far', 0.22, 1.35, gs);
    drawTrees('bg_trees_near', 0.5, 1.0, gs);
    if (G.tint && G.screen === 'game') {
      ctx.globalCompositeOperation = 'multiply'; ctx.fillStyle = G.tint; ctx.fillRect(0, 0, w, gs); ctx.globalCompositeOperation = 'source-over';
    }
  }

  function tileRow(img, k, y, x0, x1, dy) {
    const tw = img.width * k, th = img.height * k;
    for (let x = Math.floor(x0 / tw) * tw; x < x1; x += tw) ctx.drawImage(img, x, y, tw + 1, th);
    return th;
  }
  function drawGround() {
    const x0 = cam.x - 20, x1 = cam.x + cam.vw / cam.scale + 20, TT = curTheme();
    if (TT) {
      const gr = gimg(TT.k + '_gr'), tw = 1280, th = tw * gr.height / gr.width;
      ctx.fillStyle = TT.m.fill; ctx.fillRect(x0, GY + 40, x1 - x0, 600);
      for (let x = Math.floor(x0 / tw) * tw; x < x1; x += tw) ctx.drawImage(gr, x, GY - 12, tw + 1, th);
      return;
    }
    ctx.fillStyle = '#0d1840'; ctx.fillRect(x0, GY + 60, x1 - x0, 500);
    const g = gimg('ground'); if (g) tileRow(g, 0.52, GY - 5, x0, x1);
    const g2 = gimg('grass2'); if (g2) tileRow(g2, 0.5, GY - g2.height * 0.5 + 9, x0, x1);
  }
  function drawFrontGrass() {
    if (curTheme()) return;
    const g1 = gimg('grass1'); if (!g1) return;
    const x0 = cam.x - 20, x1 = cam.x + cam.vw / cam.scale + 20;
    ctx.globalAlpha = 0.92; tileRow(g1, 0.3, GY - g1.height * 0.3 + 10, x0, x1); ctx.globalAlpha = 1;
  }

  function drawSprite(img, x, y, w, h, a, flash) {
    ctx.save(); ctx.translate(x, y); ctx.rotate(a);
    ctx.drawImage(img, -w / 2, -h / 2, w, h);
    if (flash > 0) { ctx.globalAlpha = Math.min(0.5, flash * 2.5); ctx.globalCompositeOperation = 'lighter'; ctx.drawImage(img, -w / 2, -h / 2, w, h); }
    ctx.restore();
  }

  function drawBody(b) {
    const u = b.userData; if (!u) return;
    if (u.type === 'block') {
      const img = Assets.img(u.imgs[u.stage]) || Assets.img(u.imgs[0]);
      ctx.save(); ctx.translate(b.x, b.y); ctx.rotate(b.a);
      ctx.drawImage(img, b.ox - u.w / 2, b.oy - u.h / 2, u.w, u.h);
      if (u.flash > 0) { ctx.globalAlpha = Math.min(0.45, u.flash * 2.5); ctx.globalCompositeOperation = 'lighter'; ctx.drawImage(img, b.ox - u.w / 2, b.oy - u.h / 2, u.w, u.h); }
      ctx.restore();
    } else if (u.type === 'pig') {
      const r = u.hp / u.maxHp;
      let slot = r > 0.66 ? 0 : r > 0.33 ? 3 : 4;
      if (slot === 0 && u.react > 0) slot = 2; else if (slot === 0 && u.blinkT > 0) slot = 1;
      const img = Assets.img('pig_' + u.pt + '_' + slot);
      const w = img.width * S, h = img.height * S;
      ctx.save(); ctx.translate(b.x, b.y); ctx.rotate(b.a);
      ctx.drawImage(img, -w / 2, b.r - h, w, h);
      ctx.restore();
    } else if (u.type === 'bird') {
      const img = birdSprite(u.bt);
      ctx.save(); ctx.globalAlpha = u.fade >= 0 ? Math.max(0, u.fade / 1.2) : 1;
      drawSprite(img, b.x, b.y, u.w, u.h, b.a, 0); ctx.restore();
      if (u.bt === 'bomb' && u.fuse >= 0 && Math.floor(u.fuse * 10) % 2) { ctx.fillStyle = 'rgba(255,60,0,0.45)'; ctx.beginPath(); ctx.arc(b.x, b.y, b.r + 2, 0, TAU); ctx.fill(); }
    } else if (u.type === 'egg') {
      ctx.fillStyle = '#fff'; ctx.strokeStyle = '#333'; ctx.lineWidth = 2; ctx.beginPath(); ctx.ellipse(b.x, b.y, b.r * 0.85, b.r, b.a, 0, TAU); ctx.fill(); ctx.stroke();
    }
  }

  function birdOnGround(type, x) { const t = BIRDS[type], img = birdSprite(type); const w = img.width * BS, h = img.height * BS; ctx.drawImage(img, x - w / 2, GY - t.r - h / 2 + 2 * 0, w, h); }

  function drawSling(front) {
    const bx = SX, top = SY + 28;
    ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    if (!front) {
      ctx.strokeStyle = '#5a3516'; ctx.lineWidth = 12; ctx.beginPath(); ctx.moveTo(bx + 8, top - 6); ctx.lineTo(bx + 14, SY - 8); ctx.stroke();
      ctx.strokeStyle = '#7a4a22'; ctx.lineWidth = 5; ctx.beginPath(); ctx.moveTo(bx + 6, top - 6); ctx.lineTo(bx + 12, SY - 8); ctx.stroke();
    } else {
      ctx.strokeStyle = '#4a2c11'; ctx.lineWidth = 17; ctx.beginPath(); ctx.moveTo(bx, GY); ctx.lineTo(bx, top); ctx.stroke();
      ctx.strokeStyle = '#8a5a2b'; ctx.lineWidth = 8; ctx.beginPath(); ctx.moveTo(bx - 2, GY); ctx.lineTo(bx - 2, top); ctx.stroke();
      ctx.strokeStyle = '#4a2c11'; ctx.lineWidth = 13; ctx.beginPath(); ctx.moveTo(bx, top + 2); ctx.lineTo(bx - 14, SY - 6); ctx.stroke();
      ctx.strokeStyle = '#8a5a2b'; ctx.lineWidth = 6; ctx.beginPath(); ctx.moveTo(bx - 2, top + 2); ctx.lineTo(bx - 15, SY - 6); ctx.stroke();
    }
  }
  function drawBand(front, px, py) {
    ctx.strokeStyle = '#2d1a0b'; ctx.lineWidth = 7; ctx.lineCap = 'round';
    const sx = front ? SX - 14 : SX + 14, sy = SY - 6;
    ctx.beginPath(); ctx.moveTo(sx, sy); ctx.lineTo(px + (front ? -3 : 3), py + 2); ctx.stroke();
  }

  function drawTrajectory() {
    const d = G.drag, vx = (SX - d.x) * KPOW, vy = (SY - d.y) * KPOW;
    for (let i = 1; i <= 16; i++) {
      const t = i * 0.075, x = d.x + vx * t, y = d.y + vy * t + 0.5 * GRAV * t * t;
      if (y > GY) break;
      ctx.fillStyle = 'rgba(255,255,255,' + (0.95 - i * 0.04) + ')'; ctx.strokeStyle = 'rgba(0,0,0,0.35)'; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.arc(x, y, Math.max(2.2, 5.5 - i * 0.2), 0, TAU); ctx.fill(); ctx.stroke();
    }
  }

  function render() {
    if (G.screen === 'cutscene') { drawCutscene(); return; }
    drawBackground();
    cam.apply(ctx);
    if (shake > 0.5) ctx.translate(U.rand(-shake, shake) * 0.4, U.rand(-shake, shake) * 0.4);
    drawGround();
    if (G.screen !== 'game' && G.screen !== 'end') { ctx.setTransform(1, 0, 0, 1, 0, 0); return; }
    if (!G.slingGone) drawSling(false);
    // bird queue
    if (!G.queueHidden) { let qx = SX - 50; for (const t of G.queue.slice(0, 5)) { const w = birdSprite(t).width * BS; qx -= w * 0.4; birdOnGround(t, qx); qx -= w * 0.4 + 2; } }
    if (G.state === 'loading' && G.loadAnim) {
      const a = G.loadAnim, k = U.clamp(a.t, 0, 1), x = U.lerp(a.from.x, SX, k), y = U.lerp(a.from.y, SY, k) - Math.sin(k * Math.PI) * 55;
      const img = birdSprite(a.type); ctx.drawImage(img, x - img.width * BS / 2, y - img.height * BS / 2, img.width * BS, img.height * BS);
    }
    // bloques, pigs, birds
    for (const b of world.bodies) if (b.userData && b.userData.type === 'block' && !b.dead) drawBody(b);
    for (const b of world.bodies) if (b.userData && b.userData.type === 'pig' && !b.dead) drawBody(b);
    for (const b of world.bodies) if (b.userData && (b.userData.type === 'bird' || b.userData.type === 'egg') && !b.dead) drawBody(b);
    // bird in the slingshot
    if (G.cur && (G.state === 'ready')) {
      const p = G.dragging ? G.drag : { x: SX, y: SY };
      drawBand(false, p.x, p.y);
      const img = birdSprite(G.cur); ctx.drawImage(img, p.x - img.width * BS / 2, p.y - img.height * BS / 2, img.width * BS, img.height * BS);
      drawBand(true, p.x, p.y);
      if (G.dragging) drawTrajectory();
    }
    if (!G.slingGone) { ctx.globalAlpha = G.slingPop === undefined ? 1 : Math.max(0.05, G.slingPop); drawSling(true); ctx.globalAlpha = 1; }
    drawArrivals();
    drawFrontGrass();
    fx.draw(ctx); fx.drawTexts(ctx, FONT);
    if (G.debug) world.debugDraw(ctx);
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    drawBanner();
    if (G.debug) {
      const s = world.stats; ctx.fillStyle = 'rgba(0,0,0,0.65)'; ctx.fillRect(10, cv.height - 110, 300, 100);
      ctx.fillStyle = '#9f9'; ctx.font = '14px monospace';
      ['BirdJS v' + BirdJS.version, 'FPS ' + loop.fps.toFixed(0) + '  step ' + s.stepMs.toFixed(2) + ' ms', 'bodies ' + s.bodies + ' (awake ' + s.awake + ')', 'contacts ' + s.contacts + '  state ' + G.state].forEach((t, i) => ctx.fillText(t, 20, cv.height - 88 + i * 20));
    }
  }

  /* ---------------- cutscenes ---------------- */
  // view = [zoom, focus x, focus y] within the cover frame; interpolated from a to b (Ken Burns)
  const CUTS = {
    intro: { panels: [
      { img: 'cs1', a: [1.0, 0.0, 0.5], b: [1.15, 1.0, 0.5], snd: 'bird_05_select', text: 'One peaceful morning… until the birds found their nest empty.' },
      { img: 'cs2', a: [1.0, 1.0, 0.5], b: [1.35, 0.85, 0.5], snd: 'piglette_oink_a', text: 'The green pigs had stolen all the eggs and taken them to their fortress!' },
      { img: 'cs3', a: [1.0, 0.0, 0.7], b: [1.18, 0.4, 0.3], snd: 'redbird_yell0', text: 'The birds won’t stand by. It’s time to get those eggs back!' },
    ], done() { setScreen('episodes'); } },
    boss: { panels: [
      { img: 'cs2', a: [1.1, 0.0, 0.5], b: [1.7, 1.0, 0.45], snd: 'piglette_oink_a', text: 'Deep inside the fortress, King Pig is waiting… Get ready!' },
    ], done() { startLevel(7); } },
    ending: { panels: [
      { img: 'cs3', a: [1.2, 0.5, 0.3], b: [1.0, 0.2, 0.6], snd: 'level_clear_military_a', text: 'The eggs are safe! The birds have defeated King Pig.' },
      { img: 'cs1', a: [1.15, 1.0, 0.5], b: [1.0, 0.0, 0.5], snd: 'piglette_oink_a', text: 'But the green pigs never give up… will they be back?' },
    ], done() { setScreen('levels'); } },
  };
  let CS = null;
  const csDur = (p) => Math.max(5, p.text.length / 26 + 2.6);
  function playCut(name, done) {
    CS = { def: CUTS[name], idx: 0, t: 0, full: false, after: done || CUTS[name].done };
    setScreen('cutscene');
    $('csText').textContent = ''; sfx(CS.def.panels[0].snd, 0.9, 0);
  }
  function nextPanel() {
    CS.idx++; CS.t = 0; CS.full = false;
    if (CS.idx >= CS.def.panels.length) { finishCut(); return; }
    $('csText').textContent = ''; sfx(CS.def.panels[CS.idx].snd, 0.9, 0);
  }
  function finishCut() { const f = CS && CS.after; CS = null; $('cs').classList.add('hidden'); if (f) f(); }
  function tickCut(dt) {
    if (!CS) return;
    CS.t += dt;
    const p = CS.def.panels[CS.idx], n = CS.full ? p.text.length : Math.min(p.text.length, Math.floor(CS.t * 30));
    const shown = p.text.slice(0, n);
    if ($('csText').textContent !== shown) $('csText').textContent = shown;
    $('csHint').style.opacity = n >= p.text.length ? 1 : 0;
    if (CS.t > csDur(p)) nextPanel();
  }
  function tapCut() {
    if (!CS) return;
    const p = CS.def.panels[CS.idx];
    if (!CS.full && CS.t * 30 < p.text.length) CS.full = true; else nextPanel();
  }
  function drawCutscene() {
    if (!CS) return;
    const w = cv.width, h = cv.height, p = CS.def.panels[CS.idx], im = gimg(p.img);
    ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.fillStyle = '#000'; ctx.fillRect(0, 0, w, h);
    if (!im) return;
    const rx = 0, ry = h * 0.1, rw = w, rh = h * 0.74, dur = csDur(p);
    const k = Math.min(1, CS.t / dur), e = k * k * (3 - 2 * k);
    const z = U.lerp(p.a[0], p.b[0], e), fx = U.lerp(p.a[1], p.b[1], e), fy = U.lerp(p.a[2], p.b[2], e);
    const base = Math.max(rw / im.width, rh / im.height) * z, iw = im.width * base, ih = im.height * base;
    const alpha = Math.max(0, Math.min(1, CS.t / 0.7, (dur - CS.t) / 0.6));
    ctx.save(); ctx.beginPath(); ctx.rect(rx, ry, rw, rh); ctx.clip(); ctx.globalAlpha = alpha;
    ctx.drawImage(im, rx - (iw - rw) * fx, ry - (ih - rh) * fy, iw, ih);
    ctx.restore();
  }
  function enterLevel(i) {
    if (i === 7 && !saved.seen.boss) { saved.seen.boss = 1; Storage.set('progress', saved); playCut('boss'); }
    else startLevel(i);
  }

  /* ---------------- pantallas ---------------- */
  function applyUI() {
    document.querySelectorAll('[data-img]').forEach((e) => { e.src = window.IMGS[e.dataset.img]; });
    document.querySelectorAll('[data-bg]').forEach((e) => { e.style.backgroundImage = 'url(' + window.IMGS[e.dataset.bg] + ')'; });
  }
  function toast(msg, ms) {
    const t = $('toast'); t.textContent = msg; t.classList.remove('hidden');
    clearTimeout(toast.t); toast.t = setTimeout(() => t.classList.add('hidden'), ms || 4500);
  }
  function setScreen(s) {
    G.screen = s;
    for (const id of ['menu', 'episodes', 'levels', 'end', 'cs', 'infoModal']) $(id).classList.add('hidden');
    $('hud').classList.toggle('hidden', s !== 'game');
    $('pauseMenu').classList.add('hidden');
    if (s === 'menu') { $('menu').classList.remove('hidden'); Audio.music(MENU_MUSIC); }
    if (s === 'episodes') { buildEpisodes(); $('episodes').classList.remove('hidden'); Audio.music(MENU_MUSIC); }
    if (s === 'levels') { buildLevelGrid(); $('levels').classList.remove('hidden'); Audio.music(MENU_MUSIC); }
    if (s === 'cutscene') $('cs').classList.remove('hidden');
  }
  function epUnlocked(ei) { return ei === 0 || EPS[ei - 1].levels.every((_, li) => (saved.stars[EPS[ei - 1].first + li] || 0) > 0); }
  function epStars(ei) { return EPS[ei].levels.reduce((n, _, li) => n + (saved.stars[EPS[ei].first + li] || 0), 0); }
  function buildEpisodes() {
    const row = $('epRow'); row.innerHTML = '';
    EPS.forEach((E, ei) => {
      const open = epUnlocked(ei);
      const d = document.createElement('div'); d.className = 'ep' + (open ? '' : ' locked');
      d.innerHTML = '<div style="position:relative"><img class="card" src="' + window.IMGS[E.card] + '" alt="">' + (open ? '' : '<img class="lock" src="' + window.IMGS.u_locked + '" alt="">') + '</div>' +
        '<span class="en">' + (ei + 1) + '. ' + E.n + '</span><span class="status">' + (open ? '<img src="' + window.IMGS.u_ic_star + '" alt="">' + epStars(ei) + '/' + E.levels.length * 3 : 'Complete “' + EPS[ei - 1].n + '”') + '</span>';
      d.onclick = () => {
        if (!open) { sfx('menu_back', 0.6, 0); toast('Complete every level in “' + EPS[ei - 1].n + '” to unlock this episode.', 3500); return; }
        Audio.unlock(); sfx('menu_confirm', 0.9, 0); G.ep = ei; setScreen('levels');
      };
      row.appendChild(d);
    });
  }
  function buildLevelGrid() {
    const E = EPS[G.ep], g = $('grid'); g.innerHTML = '';
    $('lvTitle').textContent = E.n;
    document.querySelector('#levels .deco.l').src = window.IMGS[E.dl]; document.querySelector('#levels .deco.r').src = window.IMGS[E.dr];
    let next = -1;
    E.levels.forEach((L, li) => { const gi = E.first + li, s = saved.stars[gi] || 0; if (next < 0 && !(li > 0 && !(saved.stars[gi - 1] > 0)) && s === 0) next = li; });
    $('totalStars').innerHTML = '<img src="' + window.IMGS.u_ic_star + '" alt="">' + epStars(G.ep) + '/' + E.levels.length * 3;
    E.levels.forEach((L, li) => {
      const gi = E.first + li, s = saved.stars[gi] || 0, locked = li > 0 && !(saved.stars[gi - 1] > 0);
      const d = document.createElement('button'); d.className = 'lvb' + (li === next ? ' next' : ''); d.style.animationDelay = li * 0.06 + 's';
      const stars = [0, 1, 2].map((k) => '<img class="' + (k < s ? '' : 'off') + '" src="' + window.IMGS[k < s ? 'u_ic_star' : 'u_ic_star_empty'] + '" alt="">').join('');
      d.innerHTML = '<div class="sq" style="background-image:url(' + window.IMGS[locked ? 'u_locked' : E.btn] + ')">' + (locked ? '' : '<b>' + (li + 1) + '</b>') + '</div>' +
        '<div class="st">' + (locked ? '' : stars) + '</div><div class="nm">' + L.name + '</div>';
      d.onclick = () => { if (locked) { sfx('menu_back', 0.6, 0); return; } Audio.unlock(); sfx('menu_confirm', 0.9, 0); enterLevel(gi); };
      g.appendChild(d);
    });
  }
  function setSoundIcons() {
    const m = Audio.muted;
    $('bSnd').querySelector('img').src = window.IMGS[m ? 'u_ic_snd_off' : 'u_ic_snd_on'];
    $('bSnd2').style.opacity = m ? 0.55 : 1;
  }
  function toggleSound() { Audio.setMuted(!Audio.muted); setSoundIcons(); }
  function togglePause() {
    if (G.screen !== 'game') return;
    G.paused = !G.paused; $('pauseMenu').classList.toggle('hidden', !G.paused);
    sfx(G.paused ? 'menu_confirm' : 'menu_back', 0.7, 0);
  }
  function runTest() {
    const r = BirdJS.selfTest(), out = $('testOut');
    out.innerHTML = '<b>BirdJS v' + r.version + ' — ' + (r.ok ? 'ALL TESTS PASSED' : 'TESTS FAILED') + ' (' + r.ms + ' ms)</b>' + r.results.map((x) => '<div class="' + (x.ok ? 'ok' : 'bad') + '">' + (x.ok ? '✔ ' : '✘ ') + x.name + ' <small>' + x.info + '</small></div>').join('');
  }

  /* ---------------- arranque ---------------- */
  function resize() {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    cv.width = Math.floor(innerWidth * dpr); cv.height = Math.floor(innerHeight * dpr);
    cam.resize(cv.width, cv.height, VIEW_H); cam.clamp();
  }
  addEventListener('resize', resize); resize();

  const loop = new Loop(update, render, 1 / 120);
  window.__game = { startEndless, G, world, startLevel, LEVELS, EPS, cam, loop, playCut, setScreen, regenLevel,
    shoot(L, deg) { if (G.state !== 'ready') return false; const t = deg * Math.PI / 180; G.drag = { x: SX - L * Math.cos(t), y: SY + L * Math.sin(t) }; launch(); return true; },
    tap() { for (const b of G.flying.slice()) ability(b); } };

  applyUI();
  Audio.register(window.SNDS);
  Assets.loadImages(window.IMGS).then(() => {
    $('logo').src = window.IMGS.logo;
    $('loading').classList.add('hidden');
    setScreen('menu'); loop.start();
  });

  $('bPlay').onclick = () => {
    Audio.unlock().then(() => Audio.music(MENU_MUSIC)); sfx('menu_confirm', 0.9, 0);
    if (!saved.seen.intro) { saved.seen.intro = 1; Storage.set('progress', saved); playCut('intro'); } else setScreen('episodes');
  };
  $('bIntro').onclick = () => { Audio.unlock().then(() => Audio.music(MENU_MUSIC)); $('infoModal').classList.add('hidden'); playCut('intro'); };
  $('bFinal').onclick = () => playCut('ending');
  $('csSkip').onclick = (e) => { e.stopPropagation(); finishCut(); };
  $('cs').addEventListener('pointerdown', (e) => { if (e.target.id !== 'csSkip') tapCut(); });
  addEventListener('keydown', (e) => { if (G.screen === 'cutscene') { if (e.key === 'Escape') finishCut(); else if (e.key === ' ' || e.key === 'Enter') tapCut(); } });
  $('bTest').onclick = runTest;
  $('bBack').onclick = () => { sfx('menu_back', 0.8, 0); setScreen('episodes'); };
  $('bEpBack').onclick = () => { sfx('menu_back', 0.8, 0); setScreen('menu'); };
  $('bInfo').onclick = () => { Audio.unlock(); sfx('menu_confirm', 0.7, 0); $('infoModal').classList.remove('hidden'); };
  $('infoClose').onclick = () => { sfx('menu_back', 0.7, 0); $('infoModal').classList.add('hidden'); };
  $('bSnd2').onclick = toggleSound;
  $('bPause').onclick = togglePause;
  $('bEndless').onclick = () => { Audio.unlock().then(() => Audio.music(MENU_MUSIC)); sfx('menu_confirm', 0.9, 0); startEndless(); };
  $('bBP').onclick = () => { sfx('menu_back', 0.6, 0); toast('Bad Piggies mode is not available in this version yet.'); };
  $('bResume').onclick = togglePause;
  $('bRestart2').onclick = () => { if (G.mode === 'endless') startEndless(); else startLevel(G.level); };
  $('bRetry').onclick = () => { if (G.mode === 'endless') startEndless(); else startLevel(G.level); };
  $('bNext').onclick = () => enterLevel(G.level + 1);
  $('bMenu').onclick = () => { setScreen(G.mode === 'endless' ? 'menu' : 'levels'); };
  $('bMenu2').onclick = () => { setScreen(G.mode === 'endless' ? 'menu' : 'levels'); };
  $('bDebug').onclick = () => { G.debug = !G.debug; toast(G.debug ? 'BirdJS debug enabled' : 'Debug disabled', 1500); };
  $('bSnd').onclick = toggleSound;
})();
